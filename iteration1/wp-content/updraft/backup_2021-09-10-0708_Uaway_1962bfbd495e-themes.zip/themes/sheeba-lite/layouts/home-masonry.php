<div id="content" class="container masonry-container homepage_container">

	<?php 
	
		do_action('sheeba_lite_masonry'); 
		do_action('sheeba_lite_pagination', 'home'); 
	
	?>

</div>