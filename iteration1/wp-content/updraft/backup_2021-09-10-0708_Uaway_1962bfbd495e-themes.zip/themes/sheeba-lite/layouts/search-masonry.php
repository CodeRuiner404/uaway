<div id="content" class="container searchpage_container">
	
    <?php 

		do_action('sheeba_lite_searched_item', 'on');
		do_action('sheeba_lite_masonry', 'searchpage_container');
		do_action('sheeba_lite_pagination', 'archive');

	?>

</div>