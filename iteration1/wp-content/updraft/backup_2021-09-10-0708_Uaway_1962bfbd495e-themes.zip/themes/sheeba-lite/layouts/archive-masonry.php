<div id="content" class="container">
	
    <?php 
	
		do_action('sheeba_lite_archive_title');
		do_action('sheeba_lite_masonry', 'archive_container');
		do_action('sheeba_lite_pagination', 'archive');
		
	?>

</div>