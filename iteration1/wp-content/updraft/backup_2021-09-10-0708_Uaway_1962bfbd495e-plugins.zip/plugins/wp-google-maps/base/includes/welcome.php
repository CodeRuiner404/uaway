<?php

// Moved to /html/welcome.html.php
