<?php

namespace WPGMZA;

class RectanglePanel extends FeaturePanel
{
	public function __construct($map_id)
	{
		FeaturePanel::__construct($map_id);
	}
}