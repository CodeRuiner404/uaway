<?php

namespace WPGMZA;

class PolygonPanel extends FeaturePanel
{
	public function __construct($map_id)
	{
		FeaturePanel::__construct($map_id);
	}
}